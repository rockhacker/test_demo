package main

import (
	"forex_micro/commands/mtQuote"
	"forex_micro/commands/mtserver"
	"forex_micro/conf"
	"forex_micro/services/api"
	apiWs "forex_micro/services/api/ws"
	_ "forex_micro/services/cache/go-cache"
	"forex_micro/services/logic/microOrder"
	"forex_micro/services/model"
	"forex_micro/services/redisDB"
	"forex_micro/services/tools"
	"github.com/zh-five/xdaemon"
	"os"
)

func init() {

	//读取配置文件
	conf.Init()

	//设置时区
	_ = os.Setenv("TZ", conf.Config.GetString("basic.tz"))

	//加载日志系统
	tools.LogInit()

	//连接数据库
	model.InitDB()

	//连接Redis
	redisDB.InitRedis()
}

func main() {
	var err error

	//
	//fmt.Println(market.FormatTimeline("60min", time.Now()))
	//v := model.ForexTradeLists{}
	//
	//model.DB.Where("id = 2").First(&v)
	//fmt.Println(v.CheckMarketStatus())

	if conf.Config.GetBool("basic.daemon") {

		//启动一个子进程后主程序退出
		_, _ = xdaemon.Background(conf.Config.GetString("basic.daemonFile"), true)
	}

	//启动APi Ws客户端服务
	go apiWs.RunJobs()

	//查找行情
	//go mtserver.NewSyncMTConnect()
	go mtserver.RunMt()

	//创建携程池
	go microOrder.InitMicroClose(2000)

	//行情服务初始化
	go mtQuote.Init()

	err = api.Route().Run(conf.Config.GetString("basic.listenAndServe"))
	if err != nil {

		return
	}
}
