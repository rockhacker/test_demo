package forex

import (
	"forex_micro/services/model"
	"forex_micro/services/tools"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"strconv"
)

//TradeList 获取支持的外汇币种
func TradeList(c *gin.Context) {

	var lists []model.ForexTradeLists
	db := model.DB

	searchCurrency := c.DefaultQuery("searchCurrency", "")

	if searchCurrency != "" {

		db = db.Where("code like '%" + searchCurrency + "%'")
	}

	db.Where("trade_status = ?", model.ForexTradeOn).Preload("HasForexMultiple", func(db *gorm.DB) *gorm.DB {

		return db.Order("forex_multiples.value ASC")
	}).Preload("ForexQuotations").Order("sort desc").Find(&lists)

	//获取默认杠杆
	var mul []model.ForexMultiple

	db.Where("forex_id = 0").Find(&mul)

	for k, v := range lists {

		lists[k].MarketStatus = v.CheckMarketStatus()
		lists[k].LastPrice = strconv.FormatFloat(v.ForexQuotations.Close, 'f', -1, 64)

		if len(v.HasForexMultiple) == 0 {

			lists[k].HasForexMultiple = mul
		}
	}
	tools.Response(c, 1, "获取成功", lists)

	c.Abort()
}
