package kline

import (
	"forex_micro/commands/mtQuote"
	"forex_micro/services/market"
	"forex_micro/services/model"
	"forex_micro/services/tools"
	"github.com/gin-gonic/gin"
)

func GetKline(ctx *gin.Context) {

	forexId := ctx.DefaultQuery("forex_id", "0")
	period := ctx.DefaultQuery("period", mtQuote.Periods[0])
	//size := c.DefaultQuery("size", strconv.Itoa(apiws.KlineSize))

	forex := model.ForexTradeLists{}
	model.DB.First(&forex, forexId)

	if forex.Id == 0 {
		tools.Response(ctx, 0, "交易对不存在", nil)
		ctx.Abort()
		return
	}
	//parseSize, _ := strconv.ParseInt(size, 10, 64)
	data := market.GetKline(period, forex.Code)

	tools.Response(ctx, 1, "获取成功", data)

	ctx.Abort()
}
