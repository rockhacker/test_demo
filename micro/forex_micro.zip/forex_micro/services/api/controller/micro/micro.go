package micro

import (
	"fmt"
	go_cache "forex_micro/services/cache/go-cache"
	"forex_micro/services/logic"
	"forex_micro/services/logic/microOrder"
	"forex_micro/services/model"
	"forex_micro/services/model/microaccountmodel"
	"forex_micro/services/tools"
	"github.com/gin-gonic/gin"
	"github.com/golang-module/carbon/v2"
	log "github.com/sirupsen/logrus"
	"gorm.io/gorm"
	"math"
	"strconv"
	"time"
)

// GetSeconds 取到期时间
func GetSeconds(ctx *gin.Context) {

	var seconds []model.MicroSeconds

	key := "micro_seconds|cache"
	g, is := go_cache.GoCache.Get(key)
	if is {

		seconds = g.([]model.MicroSeconds)
	} else {

		model.DB.Where("status = ?", model.StatusOn).Order("seconds").Find(&seconds)

		go_cache.GoCache.Set(key, seconds, 360*time.Second)
	}

	tools.Response(ctx, 1, "获取成功", seconds)
}

func ServerSeconds(ctx *gin.Context) {

	data := map[string]interface{}{
		//"data": carbon.Now().ToDateTimeString(),
		"data": carbon.Now().Timestamp(),
		"now":  carbon.Now().ToDateTimeString(),
	}
	tools.Response(ctx, 1, "获取成功", data)
}

// GetPayableCurrencies 取允许支付的币种
func GetPayableCurrencies(ctx *gin.Context) {

	var currencies []model.AssociationsCurrencyToMicroNumber

	key := "payableCurrency|cache"
	g, is := go_cache.GoCache.Get(key)
	if is {

		currencies = g.([]model.AssociationsCurrencyToMicroNumber)
	} else {

		model.DB.Model(model.AssociationsCurrencyToMicroNumber{}).Where("is_quote = ?", model.QuoteOn).Preload("MicroNumbers", func(db *gorm.DB) *gorm.DB {
			return db.Order("micro_numbers.number")
		}).Find(&currencies)
		go_cache.GoCache.Set(key, currencies, 60*time.Second)
	}

	userId := model.GetUserId(ctx)

	for k, v := range currencies {

		account, _ := microaccountmodel.NewMicroAccount(model.DB).GetAccount(userId, v.Id)

		currencies[k].MicroAccount = account
	}

	tools.Response(ctx, 1, "获取成功", currencies)
}

// Lists 订单接口
func Lists(ctx *gin.Context) {

	limit, _ := strconv.Atoi(ctx.DefaultQuery("limit", "10"))
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "1"))

	status := ctx.DefaultQuery("status", "-1")
	//matchId := ctx.DefaultQuery("match_id", "-1")
	forexId := ctx.DefaultQuery("forex_id", "-1")
	currencyId := ctx.DefaultQuery("currency_id", "-1")
	orderId := ctx.DefaultQuery("order_id", "-1")
	userId := model.GetUserId(ctx)

	if orderId == "-1" {

		var orders []model.MicroOrders

		//分页
		offset := (page - 1) * limit

		w := map[string]interface{}{
			"user_id": userId,
		}
		if status != "-1" {

			w["status"] = status
		}

		if forexId != "-1" {

			w["forex_id"] = forexId
		}
		if currencyId != "-1" {

			w["currency_id"] = currencyId
		}

		model.DB.Where(w).Order("id DESC").Preload("ForexTrade").Offset(offset).Limit(limit).Order("id DESC").Find(&orders)

		for k, v := range orders {
			orders[k].CompleteAtST = carbon.Time2Carbon(v.CompleteAt).ToDateTimeString()
			orders[k].CreatedAtST = carbon.Time2Carbon(v.CreatedAt).ToDateTimeString()
			orders[k].UpdatedAtST = carbon.Time2Carbon(v.UpdatedAt).ToDateTimeString()
			orders[k].HandledAtST = carbon.Time2Carbon(v.HandledAt).ToDateTimeString()
		}

		//订单总数
		var total int64
		model.DB.Model(model.MicroOrders{}).Where(w).Count(&total)

		type rp struct {
			PerPage     int         `json:"per_page"`
			To          int         `json:"to"`
			CurrentPage int         `json:"current_page"`
			Total       int64       `json:"total"`
			Data        interface{} `json:"data"`
		}

		rps := rp{
			PerPage:     limit,
			To:          limit * page,
			CurrentPage: page,
			Total:       total,
			Data:        orders,
		}

		tools.Response(ctx, 1, "获取成功", rps)

	} else {
		var order model.MicroOrders

		w := map[string]interface{}{
			"id": orderId,
		}

		model.DB.Where(w).Preload("ForexTrade").First(&order)

		tools.Response(ctx, 1, "获取成功", order)
	}

}

func Submit(ctx *gin.Context) {

	//matchId := ctx.DefaultPostForm("match_id", "0")
	forexId, _ := strconv.Atoi(ctx.DefaultPostForm("forex_id", "0"))
	Type, _ := strconv.Atoi(ctx.DefaultPostForm("type", "0"))
	currencyId, _ := strconv.Atoi(ctx.DefaultPostForm("currency_id", "0"))
	seconds := ctx.DefaultPostForm("seconds", "0")
	number, _ := strconv.ParseFloat(ctx.DefaultPostForm("number", "0"), 64)
	//orderTime := ctx.DefaultPostForm("order_time", "")
	userId := model.GetUserId(ctx)

	forex := model.ForexTradeLists{}
	model.DB.First(&forex, forexId)

	if Type != 1 && Type != 2 {

		tools.Response(ctx, 0, "无法确定下单方向", nil)
		ctx.Abort()
		return
	}

	if forex.Id == 0 {
		tools.Response(ctx, 0, "指定交易对不存在", nil)
		ctx.Abort()
		return
	}
	if forex.TradeStatus == model.ForexTradeOff {

		tools.Response(ctx, 0, "该交易兑暂时无法交易", nil)
		ctx.Abort()
		return
	}

	if forex.CheckMarketStatus() == 2 {

		tools.Response(ctx, 0, "休市状态无法操作", nil)
		ctx.Abort()
		return
	}

	currency := model.Currencies{}
	model.DB.Where("id = ?", currencyId).First(&currency)

	if currency.Id == 0 {

		tools.Response(ctx, 0, "支付币种不存在", nil)
		ctx.Abort()
		return
	}
	//
	//matches := model.CurrencyMatches{}
	//
	//model.DB.Where("id = ?", matchId).First(&matches)
	//
	//if matches.Id == 0 {
	//	tools.Response(ctx, 0, "指定交易对不存在", nil)
	//	ctx.Abort()
	//	return
	//}
	//
	//if matches.OpenMicrotrade == 0 {
	//	tools.Response(ctx, 0, "交易未开启", nil)
	//	ctx.Abort()
	//	return
	//}

	//检测秒数是否在合法范围内
	sec := model.MicroSeconds{}
	model.DB.Where("seconds = ?", seconds).First(&sec)

	if sec.Id == 0 {
		tools.Response(ctx, 0, "到期时间不允许", nil)
		ctx.Abort()
		return
	}
	//
	////校验秒数是否正常
	//if carbon.Parse(orderTime).IsValid() {
	//	defT := carbon.Now().Timestamp() - carbon.Parse(orderTime).Timestamp()
	//	fmt.Println(defT)
	//	//if defT < 0 || defT > 20 {
	//	if defT > 20 {
	//		orderTime = ""
	//	}
	//}
	//key := "NewPrice:forex_id:" + strconv.Itoa(forexId)

	closePrice, err := logic.GetLastPrice(forexId)

	if err != nil {

		tools.Response(ctx, 0, err.Error(), nil)
		ctx.Abort()
		return
	}

	if closePrice <= 0 {

		tools.Response(ctx, 0, "获取最新价错误，请重试", nil)
		ctx.Abort()
		return
	}

	user := model.Users{}
	model.DB.Where("id = ?", userId).First(&user)

	if user.Id == 0 {

		tools.Response(ctx, 0, "用户无效", nil)
		ctx.Abort()
		return
	}

	if user.TxStatus == model.UserLock {

		tools.Response(ctx, 0, "禁止交易", nil)
		ctx.Abort()
		return
	}

	//开启事务
	tx := model.DB.Begin()

	account, err := microaccountmodel.NewMicroAccount(tx).GetAccount(userId, currencyId)

	if err != nil {

		tools.Response(ctx, 0, "获取支付账户失败", nil)
		tx.Rollback()
		ctx.Abort()
		return
	}
	//手续费
	fee := currency.MicroTradeFee * number
	if account.Balance < math.Abs(number+fee) {

		tools.Response(ctx, 0, "余额不足", nil)
		tx.Rollback()
		ctx.Abort()
		return
	}

	err = account.ChangeBalance(microaccountmodel.MicroTradeOrder, -number)

	if err != nil {
		tools.Response(ctx, 0, "扣除余额失败请重试", nil)
		tx.Rollback()
		ctx.Abort()
		return
	}

	err = account.ChangeBalance(microaccountmodel.MicroTradeOrderFee, -fee)
	if err != nil {
		tools.Response(ctx, 0, "扣除手续费失败，请重试", nil)
		tx.Rollback()
		ctx.Abort()
		return
	}

	//下单时间如果前端时间正确就用前端时间，否则用当前时间
	now := carbon.Now().ToDateTimeString()
	//if carbon.Parse(orderTime).IsValid() {
	//	now = orderTime
	//}
	carbonTime := carbon.Parse(now)
	//newOrder := map[string]interface{}{
	//	"user_id":           userId,
	//	"type":              Type,
	//	"match_id":          matches.Id,
	//	"currency_id":       currency.Id,
	//	"seconds":           sec.Seconds,
	//	"open_price":        closePrice,
	//	"end_price":         closePrice,
	//	"number":            number,
	//	"profit_ratio":      sec.ProfitRatio,
	//	"fee":               fee,
	//	"status":            model.MicroStatusOpened,
	//	"pre_profit_result": 0, //预设赢利
	//	"profit_result":     0,
	//	"fact_profits":      0,
	//	"handled_at":        carbonTime.AddSeconds(sec.Seconds).ToDateTimeString(),
	//	"agent_path":        user.AgentPath,
	//	"created_at":        carbonTime.ToDateTimeString(),
	//}
	newOrder := model.MicroOrders{
		UserId:          userId,
		Type:            Type,
		CurrencyId:      currency.Id,
		ForexId:         forexId,
		Seconds:         sec.Seconds,
		OpenPrice:       closePrice,
		EndPrice:        closePrice,
		Number:          number,
		ProfitRatio:     sec.ProfitRatio,
		Fee:             fee,
		Status:          model.MicroStatusOpened,
		PreProfitResult: 0,
		ProfitResult:    0,
		FactProfits:     0,
		HandledAt:       carbonTime.AddSeconds(sec.Seconds).Carbon2Time(),
		AgentPath:       user.AgentPath,
		CreatedAt:       carbonTime.Carbon2Time(),
	}

	if user.MicroContStatus == 0 {

		if new(model.Settings).GetMicroRiskProbabilityOn() == 1 {

			profitResult := tools.RiskByProbability(new(model.Settings).GetMicroRiskProfitProbability())

			newOrder.PreProfitResult = profitResult["pre_profit_result"].(int) //预设赢利
		}

	} else {

		profitResult := tools.RiskByProbability(user.MicroRiskProfitProbability)

		newOrder.PreProfitResult = profitResult["pre_profit_result"].(int) //预设赢利
	}

	err = tx.Create(&newOrder).Error

	if err != nil {
		fmt.Println(err)
		tools.Response(ctx, 0, "下单失败请重试", nil)
		tx.Rollback()
		ctx.Abort()
		return
	}

	//平仓逻辑，提交到携程处理
	err = microOrder.MicroClosePool.Submit(func() {
		//currencyMatchId := matches.Id
		forexId := forexId
		TimeTicker := time.NewTicker(time.Duration(int64(sec.Seconds)) * time.Second)
		<-TimeTicker.C
		TimeTicker.Stop()

		//平仓逻辑处理
		order := model.MicroOrders{}

		model.DB.Where("id = ? and status = ?", newOrder.Id, model.MicroStatusOpened).Find(&order)

		if order.Id != 0 {

			//key值+时间+currency_match_id
			//key := "evenLastPrice|" + carbon.Time2Carbon(order.HandledAt).ToDateTimeString() + "|" + strconv.Itoa(currencyMatchId)
			//g, is := go_cache.GoCache.Get(key)
			//key := "LastPriceClient|" + strconv.Itoa(matches.Id)
			//
			//g, is := go_cache.GoCache.Get(key)
			//var closePrice float64
			//if is {
			//
			//	closePrice = g.(float64)
			//} else {

			closePrice, err = logic.GetLastPrice(forexId)
			//}

			if err != nil {
				log.Warn("平仓失败")
				return
			}
			tx := model.DB.Begin()
			order.EndPrice = closePrice

			rate := float64(1)

			//判断是否预设是亏的单子
			if order.PreProfitResult == model.MicroResultLoss {

				//设置亏损但是结算价格小于或等于
				if order.Type == model.MicroTypeRise && closePrice >= order.OpenPrice {
					rate -= forex.OrderRiskRate
				}
				if order.Type == model.MicroTypeFall && closePrice <= order.OpenPrice {
					rate += forex.OrderRiskRate
				}
			}
			//判断是否预设是盈的单子
			if order.PreProfitResult == model.MicroResultProfit {
				//设置盈利
				if order.Type == model.MicroTypeRise && closePrice <= order.OpenPrice {
					rate += forex.OrderRiskRate
				}

				if order.Type == model.MicroTypeFall && closePrice >= order.OpenPrice {
					rate -= forex.OrderRiskRate
				}
			}

			if rate != 1 {
				order.EndPrice = order.OpenPrice * rate

				//redisDB.Set("push_float_price|"+strconv.Itoa(matches.Id), order.EndPrice, time.Second*5)
			}
			// 根据盈亏生成相关参数
			ProfitType := 0

			if order.OpenPrice > order.EndPrice {

				if order.Type == model.MicroTypeRise {

					ProfitType = -1
				} else {

					ProfitType = 1
				}
			} else if order.EndPrice == order.OpenPrice {

				ProfitType = 0
			} else {

				if order.Type == model.MicroTypeRise {

					ProfitType = 1
				} else {

					ProfitType = -1
				}
			}

			var factProfits float64
			var change float64

			if ProfitType == model.MicroResultProfit {
				//结算本金和利息
				capital := order.Number
				factProfits = capital * order.ProfitRatio
				change = capital + factProfits
			} else if ProfitType == model.MicroResultBalance {
				//结算本金,利息为0
				capital := order.Number
				factProfits = 0
				change = capital
			} else {
				//本金填补亏损
				//capital := 0
				//factProfits = -order.Number
				//change = float64(capital)

				//只亏损利润率
				capital := order.Number
				factProfits = capital * order.ProfitRatio
				factProfits = -factProfits
				change = capital + factProfits
			}

			order.ProfitResult = ProfitType
			order.Status = model.MicroStatusClosed
			order.FactProfits = factProfits
			order.CompleteAt = time.Now()
			tx.Save(&order)

			account, err := microaccountmodel.NewMicroAccount(tx).GetAccount(userId, currencyId)
			err = account.ChangeBalance(microaccountmodel.MicroTradeOrderClose, change)

			if err != nil {
				tx.Rollback()
				return
			}

			if change > 0 {
				//OrderCommission := model.OrderCommissions{}
				//OrderCommission.OrderId = order.Id

			}
			tx.Commit()
		}
	})
	if err != nil {

		//平仓携程满，需要等待新的携程空出，终止下单
		tools.Response(ctx, 0, "Temporarily unable to process your order, please place an order in advance", nil)
		tx.Rollback()
		ctx.Abort()
		return
	}

	tx.Commit()

	tools.Response(ctx, 1, "下单成功", newOrder)
	ctx.Abort()
	return
}

func Deal(ctx *gin.Context) {

	type response struct {
		Quotation model.ForexQuotations `json:"quotation"`
	}

	forexId, _ := strconv.Atoi(ctx.DefaultQuery("forex_id", "0"))

	var r response

	model.DB.Where("forex_id", forexId).First(&r.Quotation)

	tools.Response(ctx, 1, "", r)
	ctx.Abort()
	return

}
