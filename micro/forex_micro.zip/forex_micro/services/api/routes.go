package api

import (
	"forex_micro/conf"
	forexController "forex_micro/services/api/controller/forex"
	klineController "forex_micro/services/api/controller/kline"
	microController "forex_micro/services/api/controller/micro"
	"forex_micro/services/api/handle"
	"forex_micro/services/api/ws"
	"github.com/gin-gonic/gin"
)

func Route() *gin.Engine {

	if conf.Config.GetBool("basic.debug_mode") {

		gin.SetMode(gin.DebugMode)
	} else {

		gin.SetMode(gin.ReleaseMode)
	}

	r := gin.Default()
	//信任所有IP
	_ = r.SetTrustedProxies(nil)

	//解决跨域问题
	r.Use(handle.Cors())
	//设置多语言
	r.Use(handle.ApiLang())

	api := r.Group("api")

	v2 := api.Group("v2")

	//ws
	v2.GET("/ws", apiws.Ws.Handler())

	//需要登陆
	v2.Use(handle.ApiAuth)
	{
		micro := v2.Group("microtrade")
		{
			micro.GET("payable_currencies", microController.GetPayableCurrencies)

			micro.GET("lists", microController.Lists)
			//
			micro.POST("submit", microController.Submit)
			//micro.GET("submitA", microController.SubmitA)
		}

	}

	//无需登陆
	v2OA := api.Group("v2")
	{

		micro := v2OA.Group("microtrade")
		{
			micro.GET("seconds", microController.GetSeconds)

			micro.GET("server_seconds", microController.ServerSeconds)

		}

		market := v2OA.Group("market")
		{
			market.GET("kline", klineController.GetKline)

			//获取衍生品交易列表
			market.GET("/trade_list", forexController.TradeList)

			//获取交易详情
			market.GET("/deal", microController.Deal)

		}
	}
	return r
}
