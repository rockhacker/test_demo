package microOrder

import (
	"github.com/panjf2000/ants/v2"
	log "github.com/sirupsen/logrus"
	"strconv"
	"time"
)

var MicroClosePool *ants.Pool

//InitPooling 提前创建携程池
func InitPooling(poolNum int) {

	MicroClosePool, _ = ants.NewPool(poolNum)

	go func() {
		for true {
			log.Debug("剩余可运行平仓携程数量：" + strconv.Itoa(MicroClosePool.Free()))

			time.Sleep(1 * time.Second)
		}
	}()
}

func InitMicroClose(poolNum int) {

	InitPooling(poolNum)
}
