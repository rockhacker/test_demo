package model

const QuoteOn = 1
const QuoteOff = 0

type Currencies struct {
	Id            int `gorm:"primaryKey;unique"`
	Code          string
	MicroTradeFee float64 `json:"micro_trade_fee"`
}
