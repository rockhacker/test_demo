package model

import (
	"gorm.io/gorm"
)

type CurrencyMatches struct {
	Id                         int        `gorm:"primaryKey;unique" json:"id"`
	QuoteCurrencyId            int        `json:"quote_currency_id"`
	BaseCurrencyId             int        `json:"base_currency_id"`
	BaseCurrencyCode           string     `json:"base_currency_code"`
	QuoteCurrencyCode          string     `json:"quote_currency_code"`
	Code                       string     `gorm:"-" json:"code"`
	Symbol                     string     `gorm:"-" json:"symbol"`
	OpenMicrotrade             int        `json:"open_microtrade"`
	OpenLever                  int        `json:"open_lever"`
	OrderRiskRate              float64    `json:"order_risk_rate"`
	BaseCurrency               Currencies `json:"base_currency"`
	BaseCurrencyCodeAttribute  Currencies `gorm:"-" json:"-"`
	QuoteCurrencyCodeAttribute Currencies `gorm:"-" json:"-"`
	//CurrencyQuotation          CurrencyQuotations `gorm:"-" json:"currency_quotation"`

	//CurrencyQuotation          CurrencyQuotations `gorm:"foreignKey:currency_match_id" json:"currency_quotation"`
}

func (u *CurrencyMatches) AfterFind(tx *gorm.DB) (err error) {

	base := Currencies{}
	tx.Where("id = ?", u.BaseCurrencyId).First(&base)

	quote := Currencies{}
	tx.Where("id = ?", u.QuoteCurrencyId).First(&quote)

	if base.Code != "" && quote.Code != "" {

		u.BaseCurrency = base

		u.BaseCurrencyCode = base.Code
		u.QuoteCurrencyCode = quote.Code
		//u.Code = base.Code + "/" + quote.Code
		u.Code = base.Code + quote.Code
		u.Symbol = base.Code + "/" + quote.Code
	}

	return
}
