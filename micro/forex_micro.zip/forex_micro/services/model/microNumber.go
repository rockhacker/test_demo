package model

import (
	"encoding/json"
	accountModel "forex_micro/services/model/changeaccountmodel"
	"forex_micro/services/model/microaccountmodel"
	"gorm.io/gorm"
	"time"
)

type MicroNumbers struct {
	Id         int       `gorm:"primaryKey;unique" json:"id"`
	CurrencyId int64     `json:"currency_id"`
	Number     float64   `json:"number"`
	CreatedAt  time.Time `json:"created_at"`
	UpdatedAt  time.Time `json:"updated_at"`
}

type AssociationsCurrencyToMicroNumber struct {
	Id                   int                         `gorm:"primaryKey;unique" json:"id"`
	Code                 string                      `json:"code"`
	CreatedAt            time.Time                   `json:"created_at"`
	UpdatedAt            time.Time                   `json:"updated_at"`
	Decimal              float64                     `json:"decimal"`
	Desc                 string                      `json:"desc"`
	AccountsDisplay      string                      `json:"accounts_display"` //都展示什么账户
	MicroAccountDisplay  bool                        `json:"micro_account_display"`
	ChangeAccountDisplay bool                        `json:"change_account_display"`
	LeverAccountDisplay  bool                        `json:"lever_account_display"`
	LegalAccountDisplay  bool                        `json:"legal_account_display"`
	OptionAccountDisplay bool                        `json:"option_account_display"`
	MicroAccount         *microaccountmodel.Accounts `gorm:"-" json:"micro_account"`
	MicroNumbers         []MicroNumbers              `gorm:"foreignKey:currency_id" json:"micro_numbers"`
	Sort                 int64                       `json:"sort"`
	UsdPrice             float64                     `json:"usd_price"`
}

func (AssociationsCurrencyToMicroNumber) TableName() string {
	return "currencies"
}

func (u *AssociationsCurrencyToMicroNumber) AfterFind(tx *gorm.DB) (err error) {

	var m []string

	err = json.Unmarshal([]byte(u.AccountsDisplay), &m)
	if err != nil {
		return err
	}

	for _, v := range m {

		if accountModel.MicroAccountId == v {
			u.MicroAccountDisplay = true
		}
	}
	return
}
