package model

import (
	"time"
)

const StatusOn = 1
const StatusOff = 0

type MicroSeconds struct {
	Id          int       `gorm:"primaryKey;unique" json:"id"`
	Seconds     int       `json:"seconds"`
	Status      int       `json:"status"`
	ProfitRatio float64   `json:"profit_ratio"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}
