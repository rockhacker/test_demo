package microaccountmodel

var MicroTradeOrder = [2]interface{}{100, "交割下单"}
var MicroTradeOrderFee = [2]interface{}{101, "交割下单手续费"}
var MicroTradeOrderClose = [2]interface{}{102, "交割平仓"}

//MicroAccountLogs 秒合约钱包日志
type MicroAccountLogs struct {
	AccountLogs
}
