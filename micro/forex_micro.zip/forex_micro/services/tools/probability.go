package tools

import (
	"math/rand"
	"time"
)

//RiskByProbability 秒合约风控
func RiskByProbability(MicroRiskProfitProbability int) map[string]interface{} {

	if MicroRiskProfitProbability > 100 {
		//无法溢出
		MicroRiskProfitProbability = 100
	}

	riskLossProbability := 100 - MicroRiskProfitProbability
	var probabilityData []map[string]interface{}

	probabilityData = append(probabilityData, map[string]interface{}{
		"pre_profit_result": 1,
		"change":            MicroRiskProfitProbability,
	})
	probabilityData = append(probabilityData, map[string]interface{}{
		"pre_profit_result": -1,
		"change":            riskLossProbability,
	})

	//概率数组的总概率精度
	proSum := MicroRiskProfitProbability + riskLossProbability + 1
	var result map[string]interface{}
	//概率数组循环
	for _, v := range probabilityData {

		rand.Seed(time.Now().UnixMilli())
		randNum := rand.Intn(proSum)
		currentChange := v["change"]

		if randNum <= currentChange.(int) {
			result = v
			break
		}
		proSum -= currentChange.(int)
	}
	return result
}
