package mtserver

const WatchDogQuoteTypeMethod = "行情源"

const WatchDogQuoteStatusOn = 1
const WatchDogQuoteStatusOff = 2

var CheckQuoteAliveBool = false

func init() {

	CheckQuoteAliveBool = false
}
