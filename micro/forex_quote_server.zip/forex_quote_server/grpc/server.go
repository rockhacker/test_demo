package grpc

import (
	"context"
	"fmt"
	"forex_quote_server/commands/mtserver"
	"forex_quote_server/conf"
	"forex_quote_server/grpc/watchService"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"net"
)

type WatchServiceServer struct {
	watchService.UnimplementedWatchServiceServer
}

func (s *WatchServiceServer) PushStatus(ctx context.Context, req *watchService.StatusRequest) (*watchService.StatusResponse, error) {

	var status = mtserver.WatchDogQuoteStatusOff
	if mtserver.CheckQuoteAliveBool {

		status = mtserver.WatchDogQuoteStatusOn
	}

	return &watchService.StatusResponse{
		Method:      mtserver.WatchDogQuoteTypeMethod,
		Status:      int32(status),
		HandleAddr:  conf.Config.GetString("MT4Server.network_addr"),
		ConnectAcc:  conf.Config.GetString("MT4Server.user"),
		ConnectAddr: conf.Config.GetString("MT4Server.addr"),
	}, nil
}

func RunGrpcServer() {

	//协议类型以及ip，port
	lis, err := net.Listen("tcp", getGrpcAddr())
	if err != nil {
		fmt.Println(err)
		return
	}
	grpcServer := grpc.NewServer()

	watchService.RegisterWatchServiceServer(grpcServer, &WatchServiceServer{})

	log.Printf("grpc服务启动于: %v", lis.Addr())
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("grpc服务无法正常启动: %v", err)
	}

}

func getGrpcAddr() string {

	addr := conf.Config.GetString("basic.watchGrpcListen1")

	if addr == "" {

		addr = "0.0.0.0:8002"
	}
	return addr
}
