package logic

import (
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	apiws "forex_quote_server/services/api/ws"
	"forex_quote_server/services/redisDB"
	"github.com/go-redis/redis"
	"math"
	"strconv"
)

func GetPriceUseCurrencyId(forexId int) ([]byte, error) {

	//key := "NewPrice:server:currency_match_id:" + strconv.Itoa(currencyMatchId)
	key := "NewPrice:forex_id:" + strconv.Itoa(forexId)

	return redisDB.Get(key).Bytes()
}

func GetLastPrice(currencyMatchId int) (float64, error) {

	bytes, err := GetPriceUseCurrencyId(currencyMatchId)
	if err != nil && err != redis.Nil {
		return 0, errors.New("获取最新价格失败")
	}
	fmt.Println(string(bytes))
	quote := apiws.QuoteData{}
	err = json.Unmarshal(bytes, &quote)
	if err != nil {

		return 0, errors.New("获取最新价格失败")
	}
	//price := ByteToFloat64(bytes)

	return quote.Close, nil
}

func ByteToFloat64(bytes []byte) float64 {
	bits := binary.LittleEndian.Uint64(bytes)

	return math.Float64frombits(bits)
}
