package logic

import (
	"forex_quote_server/services/model"
	accountmodel "forex_quote_server/services/model/microaccountmodel"
	"github.com/golang-module/carbon/v2"
	log "github.com/sirupsen/logrus"
	"strconv"
	"time"
)

func MicroCloseOrderPer() {

	for {

		var orders []model.MicroOrders

		now := carbon.Now().AddSeconds(-16).ToDateTimeString()

		model.DB.Debug().Where("status = ? and handled_at <= ?", model.MicroStatusOpened, now).Order("id ASC").Limit(50).Find(&orders)
		log.Debug("秒合约平仓程序兜底运行中，找到" + strconv.Itoa(len(orders)) + "笔记录待处理")

		for _, order := range orders {
			//matches := model.CurrencyMatches{}
			forex := model.ForexTradeLists{}

			model.DB.Where("id = ?", order.ForexId).First(&forex)

			closePrice, err := GetLastPrice(order.ForexId)

			if err != nil {
				log.Warn("平仓失败")
				return
			}
			tx := model.DB.Begin()
			order.EndPrice = closePrice

			rate := float64(1)

			//判断是否预设是亏的单子
			if order.PreProfitResult == model.MicroResultLoss {

				//设置亏损但是结算价格小于或等于
				if order.Type == model.MicroTypeRise && closePrice >= order.OpenPrice {
					rate -= forex.OrderRiskRate
				}
				if order.Type == model.MicroTypeFall && closePrice <= order.OpenPrice {
					rate += forex.OrderRiskRate
				}
			}
			//判断是否预设是盈的单子
			if order.PreProfitResult == model.MicroResultProfit {
				//设置盈利
				if order.Type == model.MicroTypeRise && closePrice <= order.OpenPrice {
					rate += forex.OrderRiskRate
				}

				if order.Type == model.MicroTypeFall && closePrice >= order.OpenPrice {
					rate -= forex.OrderRiskRate
				}
			}

			if rate != 1 {
				order.EndPrice = order.OpenPrice * rate
			}
			// 根据盈亏生成相关参数
			ProfitType := 0
			if order.OpenPrice > order.EndPrice {

				if order.Type == model.MicroTypeRise {

					ProfitType = -1
				} else {

					ProfitType = 1
				}
			} else if order.EndPrice == order.OpenPrice {

				ProfitType = 0
			} else {

				if order.Type == model.MicroTypeRise {

					ProfitType = 1
				} else {

					ProfitType = -1
				}
			}
			var factProfits float64
			var change float64
			if ProfitType == model.MicroResultProfit {
				//结算本金和利息
				capital := order.Number
				factProfits = capital * order.ProfitRatio
				change = capital + factProfits
			} else if ProfitType == model.MicroResultBalance {
				//结算本金,利息为0
				capital := order.Number
				factProfits = 0
				change = capital
			} else {
				//本金填补亏损
				//capital := 0
				//factProfits = -order.Number
				//change = float64(capital)

				//只亏损利润率
				capital := order.Number
				factProfits = capital * order.ProfitRatio
				factProfits = -factProfits
				change = capital + factProfits
			}
			order.ProfitResult = ProfitType
			order.Status = model.MicroStatusClosed
			order.FactProfits = factProfits
			order.CompleteAt = time.Now()
			tx.Save(&order)

			account, err := accountmodel.NewMicroAccount(tx).GetAccount(order.UserId, order.CurrencyId)
			err = account.ChangeBalance(accountmodel.MicroTradeOrderClose, change)
			if err != nil {
				tx.Rollback()
				return
			}

			if change > 0 {
				//OrderCommission := model.OrderCommissions{}
				//OrderCommission.OrderId = order.Id

			}
			tx.Commit()

		}

		time.Sleep(10 * time.Second)
	}

}
