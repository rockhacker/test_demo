package model

import (
	"fmt"
	"github.com/golang-module/carbon/v2"
	"gorm.io/gorm"
	"time"
)

const MicroStatusOpened = 1  //交易中
const MicroStatusClosing = 2 //平仓中
const MicroStatusClosed = 3  //已平仓

const (
	MicroResultLoss    = -1
	MicroResultBalance = 0
	MicroResultProfit  = 1

	MicroTypeRise = 1 //买涨
	MicroTypeFall = 2 //买跌
)

type MicroOrders struct {
	Id     int64 `gorm:"primaryKey;unique" json:"id"`
	UserId int64 `json:"user_id"`
	//MatchId            int     `json:"match_id"`
	ForexId            int     `json:"forex_id"`
	CurrencyId         int     `json:"currency_id"`
	Type               int     `json:"type"`
	IsInsurance        int     `json:"is_insurance"`
	Seconds            int     `json:"seconds"`
	Number             float64 `json:"number"`
	OpenPrice          float64 `json:"open_price"`
	EndPrice           float64 `json:"end_price"`
	Fee                float64 `json:"fee"`
	ProfitRatio        float64 `json:"profit_ratio"`
	FactProfits        float64 `json:"fact_profits"`
	Status             int     `json:"status"`
	PreProfitResult    int     `json:"pre_profit_result"`
	ProfitResult       int     `json:"profit_result"`
	CreatedAt          time.Time
	UpdatedAt          time.Time
	HandledAt          time.Time
	CompleteAt         time.Time
	CreatedAtST        string `gorm:"-" json:"created_at"`
	UpdatedAtST        string `gorm:"-" json:"updated_at"`
	HandledAtST        string `gorm:"-" json:"handled_at"`
	CompleteAtST       string `gorm:"-" json:"complete_at"`
	AgentPath          string `json:"agent_path"`
	Settled            int    `json:"settled"`
	RemainMilliSeconds int64  `gorm:"-" json:"remain_milli_seconds"`
	//HasModified        int64  `json:"has_modified"`
	//ProfitType      int       `gorm:"-"`
}

func (u *MicroOrders) AfterFind(tx *gorm.DB) (err error) {

	handledAt := carbon.Time2Carbon(time.Time(u.HandledAt))

	now := carbon.Now()
	fmt.Println(handledAt, now.ToString())
	//是否时间已经过去
	if handledAt.IsPast() {

		u.RemainMilliSeconds = 0
	}

	u.RemainMilliSeconds = now.DiffInSeconds(handledAt) * 1000

	return
}
