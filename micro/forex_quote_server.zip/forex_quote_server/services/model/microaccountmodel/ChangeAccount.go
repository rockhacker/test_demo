package microaccountmodel

import (
	"gorm.io/gorm"
)

const (
	ChangeAccountId = "1"
	LegalAccountId  = "2"
	LeverAccountId  = "3"
	MicroAccountId  = "4"
)

//MicroAccounts 秒合约钱包
type MicroAccounts struct {
	Accounts
}

func NewMicroAccount(db *gorm.DB) *MicroAccounts {

	return &MicroAccounts{
		Accounts{
			Balance:      0,
			LockBalance:  0,
			CurrencyId:   0,
			UserId:       0,
			AccountsName: "秒合约账户",
			Db:           db,
		},
	}
}

func (c *MicroAccounts) GetAccount(userId int64, currencyId int) (*Accounts, error) {

	err := c.Db.Where("user_id = ? and currency_id = ? ", userId, currencyId).Find(&c).Error

	return &c.Accounts, err
}
